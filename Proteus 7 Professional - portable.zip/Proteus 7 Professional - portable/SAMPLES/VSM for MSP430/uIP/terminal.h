#ifndef TERMINAL_H
#define TERMINAL_H

void read_str(char* ptr, int max_sz);

#endif
