use the following configuration bits:

Oscillator:  HS
Watch dog timer:  OFF
Power up timer:  OFF
Code protect:	OFF
Brown out detect:  OFF
Low voltage program: Disable
Data EE protect:  OFF
Flash program write: OFF
Backgroud debug: Disable



When you make a new project add i2crxtx.c and 16chaser to your project files
