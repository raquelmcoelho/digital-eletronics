/********************************************************************/
/********************************************************************/
/*****                                                          *****/
/*****        L A B C E N T E R    E L E C T R O N I C S        *****/
/*****                                                          *****/
/*****       LABCENTER INTEGRATED SIMULATION ARCHITECTURE       *****/
/*****                                                          *****/
/*****                     Header Tasker Procedure              *****/
/*****                                                          *****/
/********************************************************************/
/********************************************************************/
extern void led_mux (void);
extern void led_counter (void);
extern void blink_dp (void);
extern void get_key (void);

