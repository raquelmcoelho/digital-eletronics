/********************************************************************************************************
- FB-EDU-PARM-LPC2138 Target Initial file
-
- Author: Kruck Wang(Wang RongHua)
-
- Date: 2009-04-23
-
- Guangzhou Windway Electronic Technology Co., Ltd.
********************************************************************************************************/

#ifndef TARGET_H
#define TARGET_H

// Function export
extern void Reset(void);
extern void TargetInit(void);
extern void TargetResetInit(void);

#endif
